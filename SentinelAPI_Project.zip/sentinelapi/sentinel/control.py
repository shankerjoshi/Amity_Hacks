import collections
import html
import json
import secrets
import threading
import time
import urllib.parse
import uuid
from .common import *
from . import store
from .sandbox import spec
from .scanner import Runner, BudgetExceeded, inspect_api, verify, llm_plan
from .specs import parse_spec

SESSION = secrets.token_urlsafe(32)
API_LOCKS = {api: threading.RLock() for api in DOMAINS}
SCAN_LOCK = threading.Lock()
CANCEL = set()
LIVE_RATE = {}
LAST_INCIDENT = {}
LIVE_LOCK = threading.Lock()
SETTINGS_DEFAULT = {'autonomous': True, 'continuous': False, 'interval_seconds': 120, 'api_ids': ['orders'], 'last_continuous': None}

def settings():
    return store.get('settings', 'main', SETTINGS_DEFAULT.copy())

def catalog():
    try:
        upstream = http(SANDBOX, '/internal/state', internal=True)
        states = {x['id']: x for x in upstream['body']} if upstream['status'] == 200 else {}
    except Exception:
        states = {}
    return [{**p, 'name': p['id'].title(), 'operations': 6, 'mode': 'secure' if states.get(p['id'], {}).get('secure') else 'vulnerable' if p['id'] in states else 'unreachable',
             'revision': states.get(p['id'], {}).get('revision'), 'deleted_records': len(json.loads(states.get(p['id'], {}).get('deleted', '[]'))),
             'depends_on': [DOMAINS[(DOMAINS.index(p['id'])+1) % len(DOMAINS)]]} for p in store.policies()]

def repair(api, incident_id=None):
    # Lock serializes authority changes, patch commits and route reopen for one API.
    with API_LOCKS[api]:
        if not store.policy(api)['repair']:
            store.set_policy(api, isolated=True)
            store.event('repair_denied', api, reason='No repair authority; gateway remains isolated')
            return {'status': 'isolated', 'reason': 'No repair authority'}
        store.set_policy(api, isolated=True)
        started = now()
        try:
            patch = http(SANDBOX, '/internal/change', 'POST', {'api_id': api, 'action': 'repair'}, internal=True)
            if patch['status'] != 200:
                raise ValueError('Backend patch failed')
            check = verify(api)
            if not check['passed']:
                raise ValueError('Post-repair regression checks failed')
            store.set_policy(api, isolated=False)
            result = {'status': 'repaired', 'api_id': api, 'started_at': started, 'completed_at': now(),
                      'patch': patch['body'], 'verification': check,
                      'strategy': 'Install pre-approved sandbox owner/auth/response/rate controls and restore the synthetic seed; verify before reopening.'}
            for finding in store.objects('finding', 10000):
                if finding['api_id'] == api and finding['status'] == 'open':
                    finding.update(status='resolved', resolved_at=now(), verification=check)
                    store.put('finding', finding['id'], finding)
            store.event('repaired', api, result=result)
        except Exception as exc:
            result = {'status': 'repair_failed', 'api_id': api, 'error': str(exc)[:200], 'completed_at': now(), 'isolated': True}
            store.event('repair_failed', api, result=result)
        store.put('repair', uuid.uuid4().hex, result)
        if incident_id:
            inc = store.get('incident', incident_id)
            if inc:
                inc['outcome'] = result['status']; inc['repair'] = result
                inc['timeline'].append({'time': now(), 'action': result['status'], 'detail': result})
                store.put('incident', incident_id, inc)
        return result

def contain(api, kind, detail, source='gateway', request=None):
    with API_LOCKS[api]:
        store.set_policy(api, isolated=True)
        inc = {'id': uuid.uuid4().hex[:12], 'api_id': api, 'type': kind, 'detected_at': now(), 'source': source,
               'outcome': 'isolated', 'explanation': detail, 'request': redact(request or {}),
               'timeline': [{'time': now(), 'action': 'detected', 'detail': detail},
                            {'time': now(), 'action': 'isolated', 'detail': 'Gateway stopped forwarding this API. Backend is private.'}],
               'reproduction': reproduction_for_incident(api, kind),
               'impact': 'Attempt contained at the gateway; blocked response was not delivered. Scanner evidence may prove an underlying vulnerability.',
               'authority': bool(store.policy(api)['repair'])}
        store.put('incident', inc['id'], inc)
        store.event('contained', api, incident_id=inc['id'], type=kind, source=source)
        if settings()['autonomous'] and inc['authority']:
            threading.Thread(target=repair, args=(api, inc['id']), daemon=True).start()
        return inc

def reproduction_for_incident(api, kind):
    method = 'DELETE' if kind == 'destructive_attempt' else 'GET'
    return {'method': method, 'path': f'/api/{api}/objects/1', 'identity': 'bob',
            'steps': ['Select this API in the attacker app.', 'Run the matching scenario.', 'Review the gateway response and this incident timeline.'],
            'note': 'All resources are synthetic. Repeated requests may be denied by isolation or the verified fix.'}

def start_scan(data):
    ids = selected(data)
    checks = data.get('checks', CHECKS)
    if not isinstance(checks, list) or not checks or any(c not in CHECKS for c in checks):
        raise APIError(400, 'Choose valid checks')
    budget = int(data.get('budget', 600))
    if not 1 <= budget <= 1000:
        raise APIError(400, 'Request budget must be 1 to 1000')
    imported = store.get('spec', 'current')
    plan = imported if data.get('use_imported') and imported else parse_spec(spec())
    if data.get('use_imported') and not imported:
        raise APIError(400, 'Import a definition first')
    paths = {}
    for ep in plan['endpoints']:
        if ep['candidate'] and ep['api_id'] in ids:
            path = ep['path'].replace('{id}', '1') + ('?id=1' if ep['identifier_location'] == 'query' else '')
            paths.setdefault(ep['api_id'], []).append(path)
    if not paths:
        raise APIError(400, 'No registered GET identifier candidates for the selected APIs')
    applied = 0
    if data.get('use_plan'):
        suggestions = (store.get('plan', 'current') or {}).get('suggestions', [])
        ranked = []
        for suggestion in suggestions:
            path = str(suggestion.get('path', '')).replace('{id}', '1')
            if path.endswith('/search'):
                path += '?id=1'
            if suggestion.get('check') in checks and any(path in candidates for candidates in paths.values()):
                ranked.append(path)
        for api in paths:
            original = paths[api]
            paths[api] = list(dict.fromkeys([p for p in ranked if p in original] + original))
        applied = len(set(ranked))
    if not SCAN_LOCK.acquire(blocking=False):
        raise APIError(409, 'A scan is already running')
    scan = {'id': uuid.uuid4().hex[:12], 'status': 'queued', 'started_at': now(), 'api_ids': ids,
            'checks': checks, 'budget': budget, 'requests': 0, 'completed_apis': 0, 'total_apis': len(paths),
            'endpoint_count': len(plan['endpoints']), 'finding_ids': [], 'errors': [], 'findings_count': 0,
            'planner': 'Validated test plan' if data.get('use_plan') else 'Imported specification' if data.get('use_imported') else 'Sandbox specification',
            'plan_candidates_prioritized': applied}
    store.put('scan', scan['id'], scan)
    def worker():
        runner = Runner(budget, cancelled=lambda: scan['id'] in CANCEL)
        try:
            scan['status'] = 'running'; store.put('scan', scan['id'], scan)
            for api, candidates in paths.items():
                try:
                    with API_LOCKS[api]:
                        findings = inspect_api(api, checks, runner, list(dict.fromkeys(candidates)))
                    for f in findings:
                        f['scan_id'] = scan['id']
                        store.put('finding', f['id'], f)
                        scan['finding_ids'].append(f['id'])
                    confirmed = [f for f in findings if f['confidence'] == 'Confirmed']
                    if confirmed and settings()['autonomous']:
                        inc = contain(api, 'scan_confirmed', f'{len(confirmed)} confirmed findings from authenticated differential checks.', 'scanner')
                        # Wait for the bounded repair transaction before checking the next API.
                        with API_LOCKS[api]:
                            pass
                except BudgetExceeded:
                    raise
                except Exception as exc:
                    scan['errors'].append({'api_id': api, 'error': str(exc)[:200]})
                    if runner.errors >= 3:
                        raise BudgetExceeded('Stopped after three consecutive transport errors')
                scan.update(completed_apis=scan['completed_apis']+1, requests=runner.used, findings_count=len(scan['finding_ids']))
                store.put('scan', scan['id'], scan)
            scan['status'] = 'completed' if not scan['errors'] else 'partial'
        except BudgetExceeded as exc:
            scan.update(status='cancelled' if scan['id'] in CANCEL else 'partial', error=str(exc))
        except Exception:
            scan.update(status='failed', error='Unexpected scan failure; inspect service health')
        finally:
            scan.update(requests=runner.used, finished_at=now(), findings_count=len(scan['finding_ids']))
            store.put('scan', scan['id'], scan)
            store.event('scan_finished', scan_id=scan['id'], status=scan['status'], findings=len(scan['finding_ids']))
            CANCEL.discard(scan['id']); SCAN_LOCK.release()
    threading.Thread(target=worker, daemon=True).start()
    return scan

def continuous_loop():
    while True:
        time.sleep(2)
        config = settings()
        if config['continuous'] and time.time() - config.get('last_run_epoch', 0) >= config['interval_seconds']:
            try:
                start_scan({'api_ids': config['api_ids']})
                config.update(last_run_epoch=time.time(), last_continuous=now())
                store.put('settings', 'main', config)
            except APIError:
                pass

def report():
    return {'product': 'SentinelAPI', 'track': 'Track C - Problem Statement 3', 'exported_at': now(),
            'scope': 'Synthetic sandbox only; all requests must traverse the gateway for containment.',
            'apis': catalog(), 'scans': store.objects('scan'), 'findings': store.objects('finding', 5000),
            'incidents': store.objects('incident'), 'repairs': store.objects('repair'), 'events': store.events(500)}

class ControlHandler(Handler):
    def session(self):
        if not hmac.compare_digest(self.headers.get('X-Session', ''), SESSION):
            raise APIError(403, 'Reload the local dashboard to establish a session')

    def gateway(self, path):
        parts = path.strip('/').split('/')
        if len(parts) < 3 or parts[1] not in DOMAINS:
            raise APIError(404, 'Unknown registered API')
        api = parts[1]
        if not re.fullmatch(r'/api/[a-z]+/(objects(?:/[12])?|me|search|health)', path):
            raise APIError(404, 'Unknown sandbox endpoint')
        if self.command not in ('GET', 'DELETE') or (self.command == 'DELETE' and not re.fullmatch(r'/api/[a-z]+/objects/[12]', path)):
            raise APIError(405, 'This sandbox route does not support that method')
        actor = identity(self.headers.get('Authorization', ''))
        started = time.monotonic()
        with API_LOCKS[api]:
            if store.policy(api)['isolated']:
                store.event('traffic_blocked', api, status=423, reason='isolated', method=self.command, path=path)
                return self.send({'error': 'API isolated by SentinelAPI', 'api_id': api}, 423)
            if path.endswith('/health'):
                return self.send({'status': 'ok', 'api': api})
            rid = parts[3] if len(parts) == 4 else urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get('id', [''])[0]
            owner = 'alice' if rid == '1' else 'bob' if rid == '2' else None
            threat = None
            if not actor:
                threat = ('auth', 'An unauthenticated request attempted to access a private resource.')
            elif owner and actor != owner:
                threat = ('destructive_attempt' if self.command == 'DELETE' else 'bola', f'{actor.title()} attempted to {"delete" if self.command == "DELETE" else "read"} a resource owned by {owner.title()}.')
            with LIVE_LOCK:
                key = (api, actor, self.client_address[0]); stamp = time.monotonic()
                LIVE_RATE[key] = [t for t in LIVE_RATE.get(key, []) if stamp-t < 1]
                LIVE_RATE[key].append(stamp)
                if len(LIVE_RATE[key]) > 10:
                    threat = ('rate', 'More than ten requests per second to one API from one identity and source.')
                if len(LIVE_RATE) > 1000:
                    LIVE_RATE.clear()
            if threat:
                # Suppress repeated incidents after a fix while still blocking every request.
                with LIVE_LOCK:
                    previous = LAST_INCIDENT.get((api, threat[0]), 0)
                    first = time.monotonic()-previous > 5
                    LAST_INCIDENT[(api, threat[0])] = time.monotonic()
                if first:
                    inc = contain(api, *threat, request={'method': self.command, 'path': self.path, 'identity': actor or 'anonymous', 'source_ip': self.client_address[0],
                                                       'user_agent': self.headers.get('User-Agent', '')[:150],
                                                       'attribution_note': 'User-Agent is a client claim. Detection uses the request behavior and ownership policy, not the label.'})
                    iid = inc['id']
                else:
                    iid = None
                store.event('traffic_blocked', api, type=threat[0], status=403, path=path, identity=actor)
                return self.send({'error': 'Threat blocked by SentinelAPI', 'reason': threat[0], 'incident_id': iid}, 403)
            # Pass only the recognized identity; no caller can smuggle transport credentials or scan headers.
            response = http(SANDBOX, self.path, self.command, token=TOKENS[actor], internal=True)
            fields = sensitive_paths(response['body'])
            items = response['body'].get('items', []) if isinstance(response['body'], dict) else []
            leaked = any(isinstance(x, dict) and x.get('owner_id') != actor for x in items)
            if response['status'] == 200 and (fields or leaked):
                inc = contain(api, 'exposure', 'Upstream response contained forbidden private fields or another owner’s records. Response withheld.', request={'method': self.command, 'path': path, 'field_paths': fields,
                              'source_ip': self.client_address[0], 'user_agent': self.headers.get('User-Agent', '')[:150]})
                return self.send({'error': 'Unsafe upstream response withheld', 'incident_id': inc['id']}, 403)
            store.event('traffic', api, method=self.command, path=path, identity=actor, status=response['status'], latency_ms=round((time.monotonic()-started)*1000, 2))
            return self.send(response['body'], response['status'], headers=response['headers'])

    def route(self):
        path = urllib.parse.urlsplit(self.path).path
        if path.startswith('/api/'):
            return self.gateway(path)
        if self.command == 'GET' and path in ('/', '/app.js', '/style.css'):
            return self.static('index.html' if path == '/' else path[1:])
        if path == '/health':
            return self.send({'status': 'ok', 'service': 'controller'})
        if path == '/bootstrap' and self.command == 'GET':
            return self.send({'session': SESSION, 'attacker_url': 'http://127.0.0.1:8002', 'identities': ['alice', 'bob'], 'scope': 'Synthetic sandbox'})
        if path == '/openapi.json' and self.command == 'GET':
            return self.send(spec())
        if path == '/lab/catalog' and self.command == 'GET':
            return self.send([{'id': a['id'], 'mode': a['mode'], 'isolated': a['isolated']} for a in catalog()])
        if path.startswith('/internal/'):
            self.internal()
        else:
            self.session()
        if self.command == 'GET':
            if path in ('/control/state', '/internal/state'):
                return self.send({'apis': catalog(), 'settings': settings(), 'scans': store.objects('scan', 30),
                                  'findings': store.objects('finding', 2000), 'incidents': store.objects('incident', 100),
                                  'events': store.events(100), 'repairs': store.objects('repair', 100),
                                  'spec': store.get('spec', 'current'), 'plan': store.get('plan', 'current')})
            if path == '/control/report.json':
                return self.send(report(), headers={'Content-Disposition': 'attachment; filename="sentinel-report.json"'})
            if path == '/control/report.html':
                data = report()
                rows = ''.join('<tr>'+''.join('<td>'+html.escape(str(f[k]))+'</td>' for k in ('api_id','severity','title','status'))+'</tr>' for f in data['findings'])
                body = '<!doctype html><html lang="en"><meta charset="utf-8"><title>SentinelAPI report</title><h1>SentinelAPI security report</h1><p>'+html.escape(data['scope'])+'</p><p>'+data['exported_at']+'</p><table><tr><th>API</th><th>Severity</th><th>Finding</th><th>Status</th></tr>'+rows+'</table><h2>Complete evidence and incident record</h2><pre>'+html.escape(json.dumps(data, indent=2))+'</pre></html>'
                return self.send(body, content_type='text/html', headers={'Content-Disposition': 'attachment; filename="sentinel-report.html"'})
        if self.command != 'POST':
            raise APIError(404, 'Route not found')
        data = self.json_body()
        if path in ('/control/scan', '/internal/scan'):
            return self.send(start_scan(data), 202)
        if path == '/control/cancel':
            CANCEL.add(str(data['scan_id']))
            return self.send({'status': 'cancellation_requested'})
        if path in ('/control/policy', '/internal/policy'):
            ids = selected(data)
            if type(data.get('repair')) is not bool:
                raise APIError(400, 'repair must be true or false')
            for api in ids:
                with API_LOCKS[api]:
                    store.set_policy(api, repair=data['repair'])
                    store.event('authority_changed', api, repair=data['repair'])
            return self.send({'updated': ids, 'repair_authority': data['repair']})
        if path in ('/control/action', '/internal/action'):
            ids = selected(data); action = data.get('action')
            if action not in ('repair', 'isolate', 'release', 'reset', 'verify', 'rollback'):
                raise APIError(400, 'Unknown action')
            results = []
            for api in ids:
                with API_LOCKS[api]:
                    if action == 'repair':
                        results.append(repair(api)); continue
                    if action == 'isolate':
                        store.set_policy(api, isolated=True)
                    elif action in ('release', 'verify'):
                        check = verify(api)
                        if action == 'release' and check['passed']:
                            store.set_policy(api, isolated=False)
                        results.append({'api_id': api, 'verification': check, 'released': action == 'release' and check['passed']})
                    elif action in ('reset', 'rollback'):
                        if not store.policy(api)['repair']:
                            raise APIError(403, f'No mutation authority for {api}')
                        result = http(SANDBOX, '/internal/change', 'POST', {'api_id': api, 'action': 'reset'}, internal=True)
                        if result['status'] != 200:
                            raise APIError(503, 'Backend reset failed; existing gateway policy retained')
                        # A rollback reintroduces flaws, so it always remains isolated.
                        store.set_policy(api, isolated=(action == 'rollback'))
                        for k in list(LAST_INCIDENT):
                            if k[0] == api: LAST_INCIDENT.pop(k, None)
                        results.append({'api_id': api, 'status': 'vulnerable', 'isolated': action == 'rollback'})
                    store.event('manual_'+action, api)
            return self.send({'results': results})
        if path in ('/control/settings', '/internal/settings'):
            config = settings()
            for field in ('autonomous', 'continuous'):
                if field in data:
                    if type(data[field]) is not bool: raise APIError(400, field+' must be boolean')
                    config[field] = data[field]
            if 'interval_seconds' in data:
                config['interval_seconds'] = max(30, min(int(data['interval_seconds']), 3600))
            if 'api_ids' in data:
                config['api_ids'] = selected(data)
            store.put('settings', 'main', config); store.event('settings_changed', settings=config)
            return self.send(config)
        if path == '/control/import':
            parsed = parse_spec(data.get('spec'))
            store.put('spec', 'current', parsed)
            return self.send(parsed)
        if path == '/control/plan':
            parsed = store.get('spec', 'current') or parse_spec(spec())
            plan = llm_plan(parsed['endpoints'])
            store.put('plan', 'current', plan)
            return self.send(plan)
        raise APIError(404, 'Route not found')

if __name__ == '__main__':
    store.init()
    threading.Thread(target=continuous_loop, daemon=True).start()
    serve(ControlHandler, int(os.getenv('PORT', '8000')))
