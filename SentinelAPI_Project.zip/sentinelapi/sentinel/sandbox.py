"""Synthetic backend. In Docker only the gateway can reach this service."""
import json
import sqlite3
import threading
import time
import urllib.parse
from .common import *

LOCK = threading.RLock()
RATE = {}

def db():
    DATA.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DATA / 'sandbox.sqlite', timeout=10)
    con.row_factory = sqlite3.Row
    return con

def init():
    with db() as con:
        con.execute('CREATE TABLE IF NOT EXISTS apis (id TEXT PRIMARY KEY, secure INTEGER NOT NULL, deleted TEXT NOT NULL, revision INTEGER NOT NULL)')
        for api in DOMAINS:
            con.execute('INSERT OR IGNORE INTO apis VALUES (?,0,?,1)', (api, '[]'))

def state(api):
    with db() as con:
        row = con.execute('SELECT * FROM apis WHERE id=?', (api,)).fetchone()
        if row is None:
            raise APIError(404, 'Unknown API')
        return dict(row)

def change(api, action):
    if api not in DOMAINS:
        raise APIError(404, 'Unknown API')
    with LOCK, db() as con:
        before = state(api)
        if action == 'repair':
            con.execute('UPDATE apis SET secure=1, deleted=?, revision=revision+1 WHERE id=?', ('[]', api))
        elif action == 'reset':
            con.execute('UPDATE apis SET secure=0, deleted=?, revision=revision+1 WHERE id=?', ('[]', api))
        else:
            raise APIError(400, 'Unknown operation')
        RATE.clear()
    return {'before': before, 'after': state(api), 'changes': [
        'Require a valid authenticated identity', 'Check resource owner on every read and write',
        'Return only the public response fields', 'Enforce 5 requests per second per identity and API',
        'Restore deleted synthetic records from deterministic seed']}

def record(api, rid, secure):
    owner = 'alice' if rid == '1' else 'bob'
    result = {'id': rid, 'owner_id': owner, 'api_id': api, 'label': f'{owner.title()} synthetic {api}',
              'related': {'api': DOMAINS[(DOMAINS.index(api)+1) % len(DOMAINS)], 'id': rid}}
    if not secure:
        result['private'] = {'ssn': 'SYNTHETIC-000-00-0000', 'internal_notes': 'Synthetic private lab note',
                             'credentials': {'api_key': 'FAKE-NONFUNCTIONAL-LAB-KEY'}}
    return result

def spec():
    paths = {}
    for api in DOMAINS:
        prefix = f'/api/{api}'
        common = {'security': [{'bearerAuth': []}], 'x-sentinel-api': api,
                  'x-sentinel-policy': {'owner_field': 'owner_id', 'private': True, 'forbidden_fields': ['ssn', 'api_key', 'internal_notes']},
                  'responses': {'200': {'description': 'Synthetic resource'}}}
        for suffix, methods in [('/objects', ['get']), ('/objects/{id}', ['get', 'delete']),
                                ('/me', ['get']), ('/search', ['get']), ('/health', ['get'])]:
            path = prefix + suffix
            paths[path] = {}
            for method in methods:
                op = dict(common, operationId=f'{api}_{method}_{suffix.replace("/", "_").replace("{", "").replace("}", "")}',
                          description='Private records. Only the authenticated owner may read or delete a resource. Never expose internal notes or credentials.')
                if suffix == '/objects/{id}':
                    op['parameters'] = [{'name': 'id', 'in': 'path', 'required': True, 'schema': {'type': 'string'}, 'example': '1'}]
                if suffix == '/search':
                    op['parameters'] = [{'name': 'id', 'in': 'query', 'required': True, 'schema': {'type': 'string'}, 'example': '1'}]
                if suffix == '/health':
                    op['security'] = []
                paths[path][method] = op
    return {'openapi': '3.0.3', 'info': {'title': 'SentinelAPI synthetic laboratory', 'version': '1.0'},
            'servers': [{'url': 'http://127.0.0.1:8000'}], 'paths': paths,
            'components': {'securitySchemes': {'bearerAuth': {'type': 'http', 'scheme': 'bearer'}}}}

class SandboxHandler(Handler):
    def route(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/health':
            return self.send({'status': 'ok', 'service': 'sandbox', 'synthetic': True})
        # Even vulnerable routes require the internal transport key, separate from demo user auth.
        self.internal()
        if path == '/openapi.json':
            return self.send(spec())
        if path == '/internal/state':
            return self.send([state(api) for api in DOMAINS])
        if path == '/internal/change' and self.command == 'POST':
            data = self.json_body()
            return self.send(change(data['api_id'], data['action']))
        parts = path.strip('/').split('/')
        if len(parts) < 3 or parts[0] != 'api' or parts[1] not in DOMAINS:
            raise APIError(404, 'Unknown sandbox route')
        api, resource = parts[1:3]
        with LOCK:
            s = state(api)
            secure = bool(s['secure'])
            actor = identity(self.headers.get('Authorization', ''))
            if resource == 'health':
                return self.send({'status': 'ok', 'api': api})
            if secure and actor is None:
                return self.send({'error': 'Authentication required'}, 401)
            if secure:
                # The probe header is issued only across authenticated internal transport.
                key = (api, actor, self.headers.get('X-Lab-Probe', 'live')[:80])
                stamp = time.monotonic()
                RATE[key] = [t for t in RATE.get(key, []) if stamp - t < 1]
                if len(RATE[key]) >= 5:
                    return self.send({'error': 'Rate limit reached'}, 429, headers={'Retry-After': '1', 'X-RateLimit-Limit': '5'})
                RATE[key].append(stamp)
                if len(RATE) > 2000:
                    RATE.clear()
            if resource == 'me':
                return self.send({'id': actor or 'anonymous', 'role': 'user'})
            if resource == 'objects' and len(parts) == 3 and self.command == 'GET':
                ids = [rid for rid in ('1','2') if rid not in json.loads(s['deleted']) and (not secure or ('alice' if rid == '1' else 'bob') == actor)]
                return self.send({'items': [record(api, rid, secure) for rid in ids]})
            rid = parts[3] if len(parts) == 4 else urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get('id', [''])[0]
            if resource not in ('objects', 'search') or rid not in ('1','2') or rid in json.loads(s['deleted']):
                raise APIError(404, 'Synthetic resource not found')
            owner = 'alice' if rid == '1' else 'bob'
            if secure and actor != owner:
                return self.send({'error': 'Owner authorization denied'}, 403)
            if self.command == 'DELETE':
                with db() as con:
                    deleted = json.loads(s['deleted']) + [rid]
                    con.execute('UPDATE apis SET deleted=? WHERE id=?', (json.dumps(deleted), api))
                return self.send({'deleted': rid, 'owner_id': owner, 'synthetic': True})
            if self.command != 'GET':
                raise APIError(405, 'Method not supported')
            return self.send(record(api, rid, secure))

if __name__ == '__main__':
    init()
    serve(SandboxHandler, int(os.getenv('PORT', '8001')))
