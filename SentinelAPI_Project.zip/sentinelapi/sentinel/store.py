import json
import sqlite3
import threading
import uuid
from .common import DATA, DOMAINS, now, redact

LOCK = threading.RLock()

def db():
    DATA.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DATA / 'control.sqlite', timeout=10)
    con.row_factory = sqlite3.Row
    return con

def init():
    with db() as con:
        con.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS policies (id TEXT PRIMARY KEY, repair INTEGER NOT NULL DEFAULT 0, isolated INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS objects (kind TEXT, id TEXT, data TEXT, PRIMARY KEY(kind,id));
        CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT, kind TEXT, api_id TEXT, data TEXT);
        ''')
        for api in DOMAINS:
            con.execute('INSERT OR IGNORE INTO policies(id) VALUES (?)', (api,))
    for scan in objects('scan'):
        if scan['status'] in ('queued', 'running'):
            scan.update(status='interrupted', error='Controller restarted; start a new scan')
            put('scan', scan['id'], scan)

def put(kind, key, value):
    with db() as con:
        con.execute('INSERT OR REPLACE INTO objects VALUES (?,?,?)', (kind, key, json.dumps(redact(value))))

def get(kind, key, default=None):
    with db() as con:
        row = con.execute('SELECT data FROM objects WHERE kind=? AND id=?', (kind, key)).fetchone()
    return json.loads(row['data']) if row else default

def objects(kind, limit=200):
    with db() as con:
        rows = con.execute('SELECT data FROM objects WHERE kind=? ORDER BY rowid DESC LIMIT ?', (kind, limit)).fetchall()
    return [json.loads(row['data']) for row in rows]

def policy(api):
    with db() as con:
        row = con.execute('SELECT * FROM policies WHERE id=?', (api,)).fetchone()
    return dict(row)

def policies():
    return [policy(api) for api in DOMAINS]

def set_policy(api, **kwargs):
    for field, value in kwargs.items():
        if field not in ('repair', 'isolated'):
            raise ValueError('Unknown policy')
        with db() as con:
            con.execute(f'UPDATE policies SET {field}=? WHERE id=?', (int(bool(value)), api))

def event(kind, api='', **data):
    with db() as con:
        con.execute('INSERT INTO events(time,kind,api_id,data) VALUES (?,?,?,?)', (now(), kind, api, json.dumps(redact(data))))
        # Bounded telemetry retention; findings and incident records are separately persisted.
        con.execute('DELETE FROM events WHERE seq < (SELECT COALESCE(MAX(seq),0)-5000 FROM events)')

def events(limit=100):
    with db() as con:
        rows = con.execute('SELECT * FROM events ORDER BY seq DESC LIMIT ?', (limit,)).fetchall()
    return [{**dict(r), 'data': json.loads(r['data'])} for r in rows]
