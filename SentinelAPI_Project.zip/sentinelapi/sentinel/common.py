import hmac
import json
import os
import re
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.getenv('SENTINEL_DATA', str(ROOT / 'data')))
CONTROL = os.getenv('CONTROL_URL', 'http://127.0.0.1:8000')
SANDBOX = os.getenv('SANDBOX_URL', 'http://127.0.0.1:8001')
GATEWAY = os.getenv('GATEWAY_URL', CONTROL)
KEY = os.getenv('SENTINEL_INTERNAL_KEY', '')
TOKENS = {'alice': 'lab-alice-synthetic', 'bob': 'lab-bob-synthetic'}
DOMAINS = ['orders', 'profiles', 'invoices', 'payments', 'shipping', 'inventory',
           'support', 'subscriptions', 'analytics', 'exports', 'documents', 'projects',
           'billing', 'refunds', 'bookings', 'messages', 'devices', 'teams',
           'rewards', 'contracts', 'reports', 'notifications', 'vendors', 'audit']
CHECKS = ['bola', 'exposure', 'auth', 'rate']
MAX_BODY = 1024 * 1024
SENSITIVE = re.compile(r'password|api.?key|secret|ssn|internal_notes|billing_details|authorization|token', re.I)

def now():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')

def identity(token):
    return next((who for who, value in TOKENS.items() if hmac.compare_digest(token, 'Bearer ' + value)), None)

def redact(value, depth=0):
    if depth > 30:
        return '[DEPTH LIMIT]'
    if isinstance(value, dict):
        return {str(k): '[REDACTED]' if SENSITIVE.search(str(k)) else redact(v, depth+1) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v, depth+1) for v in value[:100]]
    if isinstance(value, str):
        value = re.sub(r'Bearer\s+([^\s"\']+)',
                       lambda m: 'Bearer ' + m[1] if m[1] in ('$TOKEN_ALICE', '$TOKEN_BOB') else 'Bearer [REDACTED]',
                       value, flags=re.I)
        for token in TOKENS.values():
            value = value.replace(token, '[REDACTED]')
        return value[:12000]
    return value

def sensitive_paths(value, prefix='$'):
    result = []
    if isinstance(value, dict):
        for k, v in value.items():
            path = f'{prefix}.{k}'
            if SENSITIVE.search(k):
                result.append(path)
            result.extend(sensitive_paths(v, path))
    elif isinstance(value, list):
        for i, v in enumerate(value):
            result.extend(sensitive_paths(v, f'{prefix}[{i}]'))
    return result

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

def http(base, path, method='GET', body=None, token=None, internal=False, timeout=4, extra=None):
    # Callers choose a fixed service origin. User input can only choose a registered path.
    if not path.startswith('/') or path.startswith('//') or any(c in path for c in ['\\', '\r', '\n', '#']):
        raise ValueError('Invalid request path')
    headers = {'Accept': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    if internal:
        headers['X-Sentinel-Key'] = KEY
    headers.update(extra or {})
    data = None if body is None else json.dumps(body).encode()
    if data is not None:
        headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(base.rstrip('/') + path, data=data, headers=headers, method=method)
    started = time.monotonic()
    try:
        response = OPENER.open(req, timeout=timeout)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        raw = response.read(MAX_BODY + 1)
        if len(raw) > MAX_BODY:
            raise ValueError('Response exceeds 1 MiB safety limit')
        try:
            payload = json.loads(raw)
        except (ValueError, UnicodeDecodeError):
            payload = {'message': raw[:2000].decode(errors='replace')}
        return {'status': response.code, 'body': payload, 'latency_ms': round((time.monotonic()-started)*1000, 2),
                'headers': {k: v for k, v in response.headers.items() if k.lower() in ('retry-after', 'x-ratelimit-limit')}}

class APIError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message

class Handler(BaseHTTPRequestHandler):
    server_version = 'SentinelLab/1.0'
    protocol_version = 'HTTP/1.0'

    def setup(self):
        super().setup()
        self.connection.settimeout(8)

    def log_message(self, *_):
        pass

    def internal(self):
        if not KEY or not hmac.compare_digest(self.headers.get('X-Sentinel-Key', ''), KEY):
            raise APIError(403, 'Internal service authentication required')

    def json_body(self):
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            raise APIError(400, 'Invalid body length')
        if not 0 <= length <= MAX_BODY:
            raise APIError(413, 'Request exceeds 1 MiB limit')
        try:
            data = json.loads(self.rfile.read(length) or b'{}')
            if not isinstance(data, dict):
                raise ValueError()
            return data
        except (ValueError, RecursionError):
            raise APIError(400, 'Expected a JSON object')

    def send(self, body, status=200, content_type='application/json', headers=None):
        raw = json.dumps(body).encode() if content_type == 'application/json' else body.encode() if isinstance(body, str) else body
        self.send_response(status)
        self.send_header('Content-Type', content_type + '; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(raw)

    def static(self, file):
        types = {'.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript'}
        target = ROOT / 'web' / file
        self.send(target.read_bytes(), content_type=types[target.suffix])

    def dispatch(self):
        try:
            # DNS rebinding and cross-origin state changes are refused on all local apps.
            host = self.headers.get('Host', '')
            expected = set(os.getenv('SENTINEL_HOSTS', '127.0.0.1,localhost,controller,sandbox,attacker').split(','))
            if host.split(':')[0] not in expected:
                raise APIError(403, 'Host is not authorized')
            origin = self.headers.get('Origin')
            if origin and urllib.parse.urlsplit(origin).netloc != host:
                raise APIError(403, 'Cross-origin requests are not allowed')
            self.route()
        except APIError as exc:
            self.send({'error': exc.message}, exc.status)
        except (ValueError, KeyError, TypeError) as exc:
            self.send({'error': str(exc)[:300]}, 400)
        except (ConnectionError, socket.timeout):
            pass
        except Exception:
            self.send({'error': 'Service unavailable. Check local service health and retry.'}, 503)

    do_GET = do_POST = do_DELETE = dispatch

class BoundedServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, *args, **kwargs):
        self.slots = threading.BoundedSemaphore(24)
        super().__init__(*args, **kwargs)
    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            request.close()
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.slots.release()
            raise
    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

def serve(handler, port):
    if len(KEY) < 24:
        raise SystemExit('Set SENTINEL_INTERNAL_KEY to a random value of at least 24 characters, or use python run.py')
    server = BoundedServer((os.getenv('BIND_HOST', '127.0.0.1'), port), handler)
    print(f'{handler.__name__} listening on port {port}', flush=True)
    server.serve_forever()

def selected(data):
    ids = data.get('api_ids', [])
    if not isinstance(ids, list) or not ids or len(ids) > len(DOMAINS) or any(x not in DOMAINS for x in ids):
        raise APIError(400, 'Select one or more registered sandbox APIs')
    return list(dict.fromkeys(ids))

