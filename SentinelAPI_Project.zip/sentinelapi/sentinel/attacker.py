"""Independent HTTP client with no defender database or repair access."""
import collections
import secrets
import threading
import time
import urllib.parse
import uuid
from .common import *

SESSION = secrets.token_urlsafe(32)
JOBS = collections.deque(maxlen=30)
RUN_LOCK = threading.Lock()
STOP = threading.Event()
SCENARIOS = ['bola', 'exposure', 'auth', 'rate', 'delete', 'chain', 'legitimate']

def launch(data):
    ids = selected(data)
    scenario = data.get('scenario', 'chain')
    if scenario not in SCENARIOS:
        raise APIError(400, 'Choose a registered sandbox scenario')
    if not RUN_LOCK.acquire(blocking=False):
        raise APIError(409, 'A simulation is already running')
    STOP.clear()
    job = {'id': uuid.uuid4().hex[:12], 'started_at': now(), 'status': 'running', 'scenario': scenario,
           'api_ids': ids, 'steps': [], 'requests': 0, 'blocked': 0, 'succeeded': 0,
           'scope': 'Fixed SentinelAPI sandbox gateway only; maximum 288 requests, sequential, 4-second timeout.'}
    JOBS.appendleft(job)
    def request(api, path, who='bob', method='GET', purpose=''):
        if STOP.is_set():
            raise InterruptedError()
        if job['requests'] >= 288:
            raise ValueError('Simulation request budget exhausted')
        job['requests'] += 1
        try:
            response = http(GATEWAY, path, method=method, token=TOKENS.get(who), extra={'User-Agent': 'SentinelLab-Attacker/1.0'})
        except Exception:
            response = {'status': 0, 'body': {'error': 'Gateway unreachable'}, 'latency_ms': 0}
        blocked = response['status'] in (401,403,423,429)
        job['blocked'] += int(blocked)
        job['succeeded'] += int(200 <= response['status'] < 300)
        job['steps'].append(redact({'time': now(), 'api_id': api, 'purpose': purpose, 'method': method, 'path': path,
                                   'identity': who or 'anonymous', 'status': response['status'], 'body': response['body'], 'blocked': blocked}))
        return response
    def worker():
        try:
            for api in ids:
                base = f'/api/{api}'
                if scenario == 'bola':
                    request(api, base+'/objects/1', purpose='Try to read Alice’s object as Bob')
                elif scenario == 'delete':
                    request(api, base+'/objects/1', method='DELETE', purpose='Attempt to delete Alice’s disposable synthetic record as Bob')
                elif scenario == 'auth':
                    request(api, base+'/objects/1', who=None, purpose='Attempt unauthenticated private access')
                elif scenario == 'exposure':
                    request(api, base+'/objects/1', who='alice', purpose='Check whether forbidden fields escape the response filter')
                elif scenario == 'rate':
                    for _ in range(12):
                        request(api, base+'/me', purpose='Bounded twelve-request rate-control probe')
                elif scenario == 'legitimate':
                    request(api, base+'/objects/2', purpose='Verify Bob can read his own resource after repair')
                else:
                    request(api, base+'/me', purpose='Step 1: discover authenticated identity')
                    listing = request(api, base+'/objects', purpose='Step 2: enumerate accessible objects')
                    items = listing['body'].get('items', []) if isinstance(listing['body'], dict) else []
                    victim = next((x for x in items if isinstance(x, dict) and x.get('owner_id') == 'alice'), None)
                    rid = victim.get('id') if victim else '1'
                    rid = rid if rid in ('1','2') else '1'
                    request(api, base+'/objects/'+rid, purpose='Step 3: follow discovered foreign ID, or seeded canary ID if enumeration was blocked')
                    request(api, base+'/objects/'+rid, method='DELETE', purpose='Step 4: attempt synthetic destructive action')
                time.sleep(.1)
            job['status'] = 'completed'
        except InterruptedError:
            job['status'] = 'cancelled'
        except Exception as exc:
            job.update(status='failed', error=str(exc)[:200])
        finally:
            job['finished_at'] = now(); RUN_LOCK.release()
    threading.Thread(target=worker, daemon=True).start()
    return job

class AttackerHandler(Handler):
    def route(self):
        path = urllib.parse.urlsplit(self.path).path
        if self.command == 'GET' and path in ('/', '/attacker.js', '/style.css'):
            return self.static('attacker.html' if path == '/' else path[1:])
        if path == '/health':
            return self.send({'status': 'ok', 'service': 'attacker', 'target': 'fixed sandbox gateway'})
        if path == '/bootstrap' and self.command == 'GET':
            return self.send({'session': SESSION, 'scenarios': SCENARIOS})
        if not hmac.compare_digest(self.headers.get('X-Session', ''), SESSION):
            raise APIError(403, 'Reload the attacker app')
        if path == '/state' and self.command == 'GET':
            try:
                apis = http(GATEWAY, '/lab/catalog')['body']
            except Exception:
                apis = [{'id': x, 'mode': 'unknown', 'isolated': False} for x in DOMAINS]
            return self.send({'apis': apis, 'jobs': list(JOBS)})
        if path == '/run' and self.command == 'POST':
            return self.send(launch(self.json_body()), 202)
        if path == '/stop' and self.command == 'POST':
            STOP.set(); return self.send({'status': 'cancellation_requested'})
        raise APIError(404, 'Route not found')

if __name__ == '__main__':
    # Attacker has no controller key in Docker; base server still needs its own startup secret.
    serve(AttackerHandler, int(os.getenv('PORT', '8002')))
