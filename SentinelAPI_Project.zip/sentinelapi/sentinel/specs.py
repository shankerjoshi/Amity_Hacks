"""Strict sandbox OpenAPI adapter. No URL fetching, code execution, or remote references."""
import ast
import json
import re
from .common import APIError, DOMAINS, MAX_BODY

def yaml_subset(text):
    # Deliberately limited YAML 1.2 data subset; full YAML is supported when PyYAML is installed.
    # Refuse aliases/tags rather than risking expansion or constructor behavior.
    if re.search(r'(^|\s)[&*!][\w!]', text):
        raise ValueError('YAML tags and anchors are not accepted. Use JSON or ordinary mappings.')
    lines = []
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith('#') or raw.strip() in ('---', '...'):
            continue
        if '\t' in raw[:len(raw)-len(raw.lstrip())]:
            raise ValueError('Use spaces for YAML indentation')
        lines.append((len(raw)-len(raw.lstrip()), raw.strip()))
    def scalar(s):
        s = s.strip()
        if s in ('{}', '[]') or s[:1] in ('{', '['):
            return json.loads(s)
        if s.startswith(('"', "'")):
            return ast.literal_eval(s)
        if s in ('true', 'false'):
            return s == 'true'
        if s in ('null', '~'):
            return None
        if re.fullmatch(r'-?\d+', s):
            return int(s)
        return s
    def parse(i, indent, depth=0):
        if depth > 30:
            raise ValueError('YAML nesting exceeds limit')
        seq = lines[i][1].startswith('- ')
        result = [] if seq else {}
        while i < len(lines) and lines[i][0] == indent:
            item = lines[i][1]
            if seq:
                if not item.startswith('- '):
                    raise ValueError('Mixed YAML sequence and mapping')
                item = item[2:]
            match = re.match(r'([^:]+):(?:\s+(.*)|$)', item)
            i += 1
            if match:
                k, v = str(scalar(match[1])), match[2] or ''
                obj = {} if seq else result
                if v in ('|', '>'):
                    chunks = []
                    while i < len(lines) and lines[i][0] > indent:
                        chunks.append(lines[i][1]); i += 1
                    obj[k] = ('\n' if v == '|' else ' ').join(chunks)
                elif v:
                    obj[k] = scalar(v)
                elif i < len(lines) and lines[i][0] > indent:
                    obj[k], i = parse(i, lines[i][0], depth+1)
                else:
                    obj[k] = {}
                if seq:
                    if i < len(lines) and lines[i][0] > indent:
                        tail, i = parse(i, lines[i][0], depth+1)
                        if not isinstance(tail, dict):
                            raise ValueError('Unsupported YAML sequence structure; import JSON')
                        obj.update(tail)
                    result.append(obj)
            elif seq:
                result.append(scalar(item))
            else:
                raise ValueError('Unsupported YAML syntax. Import JSON or install optional PyYAML.')
        return result, i
    if not lines:
        raise ValueError('Empty definition')
    result, end = parse(0, lines[0][0])
    if end != len(lines):
        raise ValueError('Invalid YAML indentation')
    return result

def parse_spec(raw):
    if isinstance(raw, dict):
        doc = raw
    elif isinstance(raw, str) and len(raw.encode()) <= MAX_BODY:
        try:
            doc = json.loads(raw)
        except ValueError:
            try:
                import yaml
            except ImportError:
                doc = yaml_subset(raw)
            else:
                if re.search(r'(^|\s)[&*!][\w!]', raw):
                    raise ValueError('YAML anchors and tags are not accepted')
                doc = yaml.safe_load(raw)
    else:
        raise ValueError('Provide a JSON or YAML API definition under 1 MiB')
    if not isinstance(doc, dict) or not (str(doc.get('openapi', '')).startswith('3.') or doc.get('swagger') == '2.0'):
        raise ValueError('Expected OpenAPI 3.x or Swagger 2.0')
    paths = doc.get('paths')
    if not isinstance(paths, dict) or not paths or len(paths) > 1000:
        raise ValueError('Definition must contain 1 to 1000 paths')
    encoded = json.dumps(doc)
    if len(encoded) > MAX_BODY:
        raise ValueError('Definition too large')
    def references(node, depth=0):
        if depth > 35:
            raise ValueError('Definition nesting exceeds limit')
        if isinstance(node, dict):
            if '$ref' in node and not str(node['$ref']).startswith('#/'):
                raise ValueError('External references are disabled')
            for value in node.values(): references(value, depth+1)
        elif isinstance(node, list):
            for value in node: references(value, depth+1)
    references(doc)
    endpoints = []
    for path, item in paths.items():
        if not isinstance(item, dict):
            raise ValueError('Each path must be an object')
        for method, op in item.items():
            if method.lower() not in ('get', 'post', 'put', 'patch', 'delete', 'head', 'options'):
                continue
            if not isinstance(op, dict):
                raise ValueError('Each operation must be an object')
            # Never trust servers, host, operation IDs or extension fields as network authority.
            match = re.fullmatch(r'/api/([a-z]+)/(?:(objects)(/\{id\})?|me|search|health)', path)
            api = match[1] if match and match[1] in DOMAINS else None
            description = str(op.get('description', ''))[:2000]
            boundary = 'owner' if re.search(r'owner|own |belong|private', description, re.I) else 'unspecified'
            params = item.get('parameters', []) + op.get('parameters', [])
            endpoints.append({'method': method.upper(), 'path': path, 'api_id': api,
                              'candidate': method == 'get' and api is not None and ('{id}' in path or path.endswith('/search')),
                              'identifier_location': 'path' if '{id}' in path else 'query' if path.endswith('/search') else None,
                              'operation_id': str(op.get('operationId', method+' '+path)), 'description': description,
                              'parameters': params, 'auth_required': bool(op.get('security', doc.get('security', []))),
                              'inferred_boundary': boundary, 'scope': 'registered sandbox' if api else 'inventory only'})
    return {'title': str(doc.get('info', {}).get('title', 'Imported definition'))[:100], 'endpoints': endpoints,
            'warnings': ['Server URLs are ignored. Only registered sandbox routes can be executed.',
                         'GET path/query ID tests are supported. Body IDs and arbitrary API adapters need implementation.']}
