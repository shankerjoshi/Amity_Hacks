import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sentinel.specs import parse_spec, yaml_subset
from sentinel.sandbox import spec
from sentinel.common import redact, sensitive_paths, TOKENS
from sentinel.scanner import Runner, BudgetExceeded

def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]

def call(base, path, body=None, headers=None, method=None):
    req = urllib.request.Request(base+path, data=None if body is None else json.dumps(body).encode(),
                                 method=method or ('GET' if body is None else 'POST'),
                                 headers={'Content-Type': 'application/json', **(headers or {})})
    try:
        res = urllib.request.urlopen(req, timeout=15)
    except urllib.error.HTTPError as exc:
        res = exc
    with res:
        raw = res.read()
        try: data = json.loads(raw)
        except ValueError: data = raw.decode()
        return res.status, data

class UnitTests(unittest.TestCase):
    def test_spec_has_144_operations_and_48_candidates(self):
        result = parse_spec(spec())
        self.assertEqual(len(result['endpoints']), 144)
        self.assertEqual(sum(e['candidate'] for e in result['endpoints']), 48)
    def test_unregistered_urls_are_inventory_only(self):
        result = parse_spec({'openapi':'3.0.3','servers':[{'url':'http://169.254.169.254'}], 'paths':{'/metadata/{id}':{'get':{}}}})
        self.assertFalse(result['endpoints'][0]['candidate'])
    def test_remote_references_rejected(self):
        with self.assertRaises(ValueError):
            parse_spec({'openapi':'3.0.3','paths':{'/x':{'$ref':'http://example.com/spec'}}})
    def test_invalid_spec_rejected(self):
        for value in ['garbage', '{}', {'openapi':'3.0.3','paths':{}}, []]:
            with self.assertRaises(ValueError): parse_spec(value)
    def test_yaml_and_swagger(self):
        text = '''swagger: "2.0"
info:
  title: YAML example
paths:
  /api/orders/objects/{id}:
    get:
      description: Only the owner can read this private record
      parameters:
        - name: id
          in: path
          required: true
      responses:
        "200":
          description: OK
'''
        parsed = parse_spec(text)
        self.assertTrue(parsed['endpoints'][0]['candidate'])
        self.assertEqual(parsed['endpoints'][0]['inferred_boundary'], 'owner')
    def test_yaml_anchors_rejected(self):
        with self.assertRaises(ValueError): yaml_subset('root: &alias\n  a: value\ncopy: *alias')
    def test_redacts_nested_fields_and_credentials(self):
        data = {'items':[{'ssn':'SECRET','nested':{'api_key':'FAKE'}}], 'text':'Bearer '+TOKENS['alice']}
        self.assertEqual(sensitive_paths(data), ['$.items[0].ssn','$.items[0].nested.api_key'])
        text = json.dumps(redact(data))
        self.assertNotIn('SECRET', text); self.assertNotIn('FAKE', text); self.assertNotIn(TOKENS['alice'], text)
        self.assertEqual(redact('Bearer $TOKEN_ALICE'), 'Bearer $TOKEN_ALICE')
        self.assertEqual(redact('Bearer $TOKEN_BOB'), 'Bearer $TOKEN_BOB')
        self.assertEqual(redact('Bearer $UNKNOWN_VALUE'), 'Bearer [REDACTED]')
    def test_budget_and_consecutive_error_limit(self):
        r = Runner(1)
        with patch('sentinel.scanner.http', return_value={'status':200,'body':{}}):
            r.call('/api/orders/me')
            with self.assertRaises(BudgetExceeded): r.call('/api/orders/me')
        r = Runner(10)
        with patch('sentinel.scanner.http', side_effect=TimeoutError()):
            for _ in range(3):
                with self.assertRaises(TimeoutError): r.call('/api/orders/me')
            with self.assertRaises(BudgetExceeded): r.call('/api/orders/me')
    def test_cancellation(self):
        with self.assertRaises(BudgetExceeded): Runner(cancelled=lambda: True).call('/api/orders/me')
    def test_no_redirects(self):
        from sentinel.common import NoRedirect
        self.assertIsNone(NoRedirect().redirect_request(None,None,302,'',{},'http://example.com'))
    def test_response_size_cap(self):
        from sentinel.common import http, MAX_BODY
        from unittest.mock import MagicMock
        response = MagicMock(); response.__enter__.return_value = response; response.read.return_value=b'x'*(MAX_BODY+1)
        with patch('sentinel.common.OPENER.open',return_value=response):
            with self.assertRaises(ValueError): http('http://127.0.0.1:8001','/health')
    def test_llm_validates_suggestions_and_redacts_prompt(self):
        from sentinel.scanner import llm_plan
        endpoints=parse_spec(spec())['endpoints']
        endpoints[1]['description']='Private owner data. Bearer secret-value'
        output={'suggestions':[{'path':'/api/orders/objects/{id}','check':'bola','reason':'Owner check'},
                               {'path':'http://external.invalid','check':'bola','reason':'invalid'},
                               {'path':'/api/orders/objects/{id}','check':'delete','reason':'invalid'}]}
        with patch.dict(os.environ,{'OLLAMA_MODEL':'test-fixture'}), patch('sentinel.scanner.http',return_value={'status':200,'body':{'response':json.dumps(output)}}) as request:
            result=llm_plan(endpoints)
            self.assertTrue(result['model_used']);self.assertEqual(len(result['suggestions']),1)
            self.assertNotIn('secret-value',request.call_args.args[3]['prompt'])
    def test_llm_invalid_and_unavailable_fallback(self):
        from sentinel.scanner import llm_plan
        endpoints=parse_spec(spec())['endpoints']
        with patch.dict(os.environ,{'OLLAMA_MODEL':'test-fixture'}):
            with patch('sentinel.scanner.http',return_value={'status':200,'body':{'response':'not json'}}):
                self.assertFalse(llm_plan(endpoints)['model_used'])
            with patch('sentinel.scanner.http',side_effect=TimeoutError()):
                self.assertFalse(llm_plan(endpoints)['model_used'])
    def test_failed_repair_remains_isolated(self):
        from sentinel.control import repair
        with patch('sentinel.control.store.policy',return_value={'repair':True}), \
             patch('sentinel.control.store.set_policy') as policy, \
             patch('sentinel.control.store.event'), patch('sentinel.control.store.put'), \
             patch('sentinel.control.http',side_effect=TimeoutError('Backend unavailable')):
            result=repair('orders')
            self.assertEqual(result['status'],'repair_failed')
            self.assertTrue(result['isolated'])
            self.assertEqual(policy.call_args_list[0].kwargs,{'isolated':True})
            self.assertFalse(any(c.kwargs.get('isolated') is False for c in policy.call_args_list))

class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='sentinel-tests-')
        cls.key = secrets.token_urlsafe(36)
        ports = [free_port() for _ in range(3)]
        cls.control, cls.sandbox, cls.attacker = [f'http://127.0.0.1:{p}' for p in ports]
        cls.children = []
        env = {**os.environ, 'SENTINEL_DATA':cls.tmp.name, 'SENTINEL_INTERNAL_KEY':cls.key,
               'CONTROL_URL':cls.control, 'SANDBOX_URL':cls.sandbox, 'GATEWAY_URL':cls.control, 'PYTHONUNBUFFERED':'1'}
        for module, port in [('sandbox',ports[1]),('control',ports[0]),('attacker',ports[2])]:
            child = subprocess.Popen([sys.executable,'-m','sentinel.'+module], cwd=ROOT,
                                     env={**env,'PORT':str(port),'SENTINEL_INTERNAL_KEY':secrets.token_urlsafe(36) if module=='attacker' else cls.key},
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            cls.children.append(child)
            for _ in range(70):
                try:
                    if call(f'http://127.0.0.1:{port}','/health')[0]==200: break
                except Exception: time.sleep(.1)
            else:
                cls.tearDownClass(); raise RuntimeError(module+' did not start')
        cls.session = call(cls.control,'/bootstrap')[1]['session']
        cls.attack_session = call(cls.attacker,'/bootstrap')[1]['session']

    @classmethod
    def tearDownClass(cls):
        for p in cls.children:
            p.terminate()
        for p in cls.children:
            p.wait(timeout=5)
        cls.tmp.cleanup()

    def c(self,path,data=None):
        return call(self.control,path,data,{'X-Session':self.session})
    def s(self,path,who='alice',method='GET'):
        return call(self.sandbox,path,headers={'X-Sentinel-Key':self.key, **({'Authorization':'Bearer '+TOKENS[who]} if who else {})},method=method)
    def snapshot(self):
        return self.c('/control/state')[1]
    def wait(self, predicate, timeout=10):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            result=predicate()
            if result:return result
            time.sleep(.05)
        self.fail('Timed out waiting for expected state')
    def scan(self, **kwargs):
        status, scan = self.c('/control/scan', {'api_ids':['orders'], **kwargs})
        self.assertEqual(status,202,scan)
        return self.wait(lambda: next((s for s in self.snapshot()['scans'] if s['id']==scan['id'] and s['status'] not in ('running','queued')),None))
    def setUp(self):
        self.c('/control/settings', {'autonomous':False,'continuous':False})
        self.c('/control/policy', {'api_ids':['orders','profiles'],'repair':True})
        self.c('/control/action', {'api_ids':['orders','profiles'],'action':'reset'})
        self.c('/control/policy', {'api_ids':['profiles'],'repair':False})

    def test_three_repeatable_vulnerable_scans_then_clean_secure_scan(self):
        for _ in range(3):
            scan=self.scan()
            self.assertEqual(scan['status'],'completed')
            fs=[f for f in self.snapshot()['findings'] if f['scan_id']==scan['id']]
            self.assertEqual({f['type'] for f in fs},{'bola','auth','exposure','rate'})
            self.assertTrue(all(f['evidence'] and f['reproduction'] for f in fs))
        status,result=self.c('/control/action',{'api_ids':['orders'],'action':'repair'})
        self.assertEqual(result['results'][0]['status'],'repaired',result)
        self.assertEqual(self.scan()['findings_count'],0)
        self.assertEqual(self.s('/api/orders/objects/1','bob')[0],403)
        self.assertEqual(self.s('/api/orders/objects/1','alice')[0],200)
    def test_autonomous_detection_repairs_only_authorized_api(self):
        self.c('/control/settings',{'autonomous':True})
        for name in ('orders','profiles'):
            status,_=call(self.control,f'/api/{name}/objects/1',headers={'Authorization':'Bearer '+TOKENS['bob']},method='DELETE')
            self.assertEqual(status,403)
        self.wait(lambda: any(a['id']=='orders' and a['mode']=='secure' and not a['isolated'] for a in self.snapshot()['apis']))
        apis={a['id']:a for a in self.snapshot()['apis']}
        self.assertEqual(apis['profiles']['mode'],'vulnerable')
        self.assertTrue(apis['profiles']['isolated'])
        self.assertFalse(apis['profiles']['repair'])
        self.assertEqual(self.s('/api/profiles/objects/1')[0],200)
        self.assertEqual(apis['profiles']['deleted_records'],0)
    def test_manual_mode_blocks_without_modifying_backend(self):
        code,_=call(self.control,'/api/orders/objects/1',headers={'Authorization':'Bearer '+TOKENS['bob']})
        self.assertEqual(code,403)
        a=next(a for a in self.snapshot()['apis'] if a['id']=='orders')
        self.assertEqual(a['mode'],'vulnerable'); self.assertTrue(a['isolated'])
    def test_no_authority_repair_and_reset(self):
        result=self.c('/control/action',{'api_ids':['profiles'],'action':'repair'})[1]
        self.assertEqual(result['results'][0]['status'],'isolated')
        self.assertEqual(self.c('/control/action',{'api_ids':['profiles'],'action':'reset'})[0],403)
        self.assertEqual(self.s('/api/profiles/objects/1','bob')[0],200)
    def test_verify_does_not_release_vulnerable_api(self):
        self.c('/control/action',{'api_ids':['orders'],'action':'isolate'})
        result=self.c('/control/action',{'api_ids':['orders'],'action':'release'})[1]
        self.assertFalse(result['results'][0]['released'])
    def test_real_synthetic_delete_and_restoration(self):
        self.assertEqual(self.s('/api/orders/objects/1','bob',method='DELETE')[0],200)
        self.assertEqual(self.s('/api/orders/objects/1')[0],404)
        self.c('/control/action',{'api_ids':['orders'],'action':'repair'})
        self.assertEqual(self.s('/api/orders/objects/1')[0],200)
        self.assertEqual(self.s('/api/orders/objects/1','bob',method='DELETE')[0],403)
    def test_gateway_suppresses_sensitive_upstream_response(self):
        code,body=call(self.control,'/api/orders/objects/1',headers={'Authorization':'Bearer '+TOKENS['alice']})
        self.assertEqual(code,403); self.assertNotIn('private',body)
    def test_budget_partial_is_not_clean_success(self):
        scan=self.scan(budget=1)
        self.assertEqual(scan['status'],'partial'); self.assertEqual(scan['requests'],1)
    def test_missing_baseline_is_partial_not_clean(self):
        self.s('/api/orders/objects/1','bob',method='DELETE')
        scan=self.scan()
        self.assertEqual(scan['status'],'partial')
        self.assertIn('Baseline unavailable',scan['errors'][0]['error'])
    def test_all_24_apis_within_budget(self):
        from sentinel.common import DOMAINS
        # Restore the two APIs modified by earlier tests; all other fixtures are pristine.
        scan=self.scan(api_ids=DOMAINS,budget=600)
        self.assertEqual(scan['status'],'completed',scan)
        self.assertEqual(scan['completed_apis'],24)
        self.assertLessEqual(scan['requests'],600)
    def test_verified_rate_control(self):
        self.c('/control/action',{'api_ids':['orders'],'action':'repair'})
        codes=[self.s('/api/orders/me')[0] for _ in range(8)]
        self.assertIn(429,codes)
    def test_continuous_scan_runs_selected_scope(self):
        old={s['id'] for s in self.snapshot()['scans']}
        self.c('/control/settings',{'continuous':True,'api_ids':['orders'],'interval_seconds':30})
        try:
            scan=self.wait(lambda:next((s for s in self.snapshot()['scans'] if s['id'] not in old and s['status']=='completed'),None))
            self.assertEqual(scan['api_ids'],['orders'])
        finally:
            self.c('/control/settings',{'continuous':False})
    def test_plan_is_applied_without_expanding_scope(self):
        self.c('/control/import',{'spec':spec()})
        self.c('/control/plan',{})
        scan=self.scan(use_plan=True)
        self.assertEqual(scan['api_ids'],['orders'])
        self.assertEqual(scan['plan_candidates_prioritized'],2)
    def test_export_has_no_raw_tokens_or_sensitive_values(self):
        self.scan()
        text=json.dumps(self.c('/control/report.json')[1])
        for secret in [*TOKENS.values(),self.key,'SYNTHETIC-000-00-0000','FAKE-NONFUNCTIONAL-LAB-KEY']:
            self.assertNotIn(secret,text)
        self.assertIn('[REDACTED]',text)
        self.assertEqual(self.c('/control/report.html')[0],200)
    def test_auth_csrf_host_and_scope_guards(self):
        self.assertEqual(call(self.sandbox,'/api/orders/objects/1')[0],403)
        self.assertEqual(call(self.control,'/control/scan',{'api_ids':['orders']})[0],403)
        self.assertEqual(call(self.control,'/control/scan',{'api_ids':['orders']},{'X-Session':self.session,'Origin':'http://evil.invalid'})[0],403)
        self.assertEqual(call(self.control,'/bootstrap',headers={'Host':'evil.invalid'})[0],403)
        self.assertEqual(self.c('/control/scan',{'api_ids':['http://example.com']})[0],400)
    def test_import_remote_url_never_executed(self):
        doc={'openapi':'3.0.3','info':{'title':'Untrusted'},'servers':[{'url':'http://169.254.169.254'}], 'paths':{'/metadata/{id}':{'get':{}}}}
        self.assertEqual(self.c('/control/import',{'spec':doc})[0],200)
        self.assertEqual(self.c('/control/scan',{'api_ids':['orders'],'use_imported':True})[0],400)
    def test_imported_query_identifier_is_scanned(self):
        doc={'openapi':'3.0.3','paths':{'/api/orders/search':{'get':{'description':'Private owner only'}}}}
        self.c('/control/import',{'spec':doc})
        scan=self.scan(use_imported=True,checks=['bola'])
        fs=[f for f in self.snapshot()['findings'] if f['scan_id']==scan['id']]
        self.assertEqual(len(fs),1);self.assertEqual(fs[0]['endpoint'],'/api/orders/search?id=1')
    def test_attacker_is_independent_and_requests_are_blocked(self):
        self.c('/control/settings',{'autonomous':True})
        status,job=call(self.attacker,'/run',{'api_ids':['orders','profiles'],'scenario':'delete'},{'X-Session':self.attack_session})
        self.assertEqual(status,202)
        finished=self.wait(lambda:next((j for j in call(self.attacker,'/state',headers={'X-Session':self.attack_session})[1]['jobs'] if j['id']==job['id'] and j['status']!='running'),None))
        self.assertEqual(finished['requests'],2);self.assertEqual(finished['blocked'],2)
    def test_planner_without_external_model(self):
        self.c('/control/import',{'spec':spec()})
        code,plan=self.c('/control/plan',{})
        self.assertEqual(code,200);self.assertFalse(plan['model_used']);self.assertGreater(len(plan['suggestions']),0)
    def test_rollback_keeps_api_isolated(self):
        self.c('/control/action',{'api_ids':['orders'],'action':'repair'})
        self.c('/control/action',{'api_ids':['orders'],'action':'rollback'})
        api=next(a for a in self.snapshot()['apis'] if a['id']=='orders')
        self.assertTrue(api['isolated']);self.assertEqual(api['mode'],'vulnerable')

if __name__=='__main__': unittest.main(verbosity=2)
