# Deploy, use and test SentinelAPI

## Local Windows deployment

1. Extract the project ZIP into a normal folder.
2. Open PowerShell in the extracted `sentinelapi` folder.
3. Check Python: `python --version` should report 3.10 or newer.
4. Run `python run.py`.
5. Open http://127.0.0.1:8000 and http://127.0.0.1:8002.

On macOS/Linux, the same files work with Python 3.10+; the command may be `python3 run.py`. The application was exercised on Windows. The included workflow runs the same Python tests on Ubuntu when pushed to GitHub.

The launcher starts the private sandbox on 8001, controller/gateway on 8000, and attacker on 8002. Only the dashboard and attacker app should be used in the browser. Direct sandbox API calls require the internal transport credential, so simply finding port 8001 does not expose its intentionally vulnerable routes.

The default Python launcher is a development server. For a demonstration with network separation, use Docker Compose. Do not expose these control panels publicly as though they had production authentication.

## Docker deployment

Run from the project root:

```sh
python configure.py
docker compose up --build -d
docker compose ps
```

The host mappings bind only to `127.0.0.1`. The sandbox has no published port. A private `backend` network connects the controller and sandbox; the attacker lives on the `frontend` network and can reach only the controller. Separate generated keys prevent the attacker startup key from authorizing internal backend calls.

The controller and backend have persistent named volumes. Containers run with no added Linux capabilities, no privilege escalation, a non-root user, and read-only application files. SQLite writes go to `/app/data`. The base image is `python:3.12-slim`; for a repeatable supply-chain process, pin an approved image digest before publishing externally.

Stop services with `docker compose down`. To restart the same state, use `docker compose up -d`. Do not delete the named volumes unless you want to discard the saved lab history. The UI's per-API reset is the normal way to repeat demos.

Docker was unavailable in the implementation environment. The Compose configuration is supplied but its container startup has not been verified here. The zero-dependency Python deployment and automated three-process tests were run successfully.

## Remote demonstration using a private host

Deploy the same Compose project on a machine you administer, keep the ports bound to loopback, and use a tunnel from your laptop:

```sh
ssh -L 8000:127.0.0.1:8000 -L 8002:127.0.0.1:8002 user@your-host
```

Open the same local URLs on your laptop. This preserves the intended single-operator boundary. A public website deployment would require an authentication layer and a reviewed gateway/network configuration that this lab does not include. No cloud account, public deployment or paid service was created by this task.

## Evidence-first manual demonstration

For a clean explanation before repairs occur, open **Automation** and disable autonomous response. Select Orders in **Scan workspace** and run all checks. A normal vulnerable Orders scan produces two sets of BOLA/exposure/auth findings (one path-ID and one query-ID route) plus one rate observation: seven findings total.

Open a BOLA finding. The baseline shows Alice reading object 1. The probe shows Bob receiving the same ID and owner marker. Open the exposure finding to see the exact nested private fields with their values redacted. Anonymous access has a separate finding. The Info rate item means only that no limit was seen in the eight-request probe.

Grant Orders repair authority in **API inventory**, then select **Repair & verify**. The repair result should show owner read 200, cross-user read 403, anonymous read 401, zero remaining findings and a passed result. Scan again to prove the repaired state. Re-enable autonomous response for the live attacker demonstration.

## Attacker scenarios

| Scenario | Request behavior | Expected defense |
|---|---|---|
| Cross-user resource access | Bob requests Alice's object 1 | Request blocked; API isolated; authorized automatic repair may follow |
| Delete another user's synthetic record | Bob sends DELETE for Alice's object | Destructive attempt blocked before backend mutation |
| Private field exposure | Alice requests her own object from a vulnerable API | Unsafe upstream response withheld, incident created |
| Unauthenticated access | No user token on private resource | Request blocked and incident created |
| Bounded rate probe | Twelve sequential `/me` requests | Backend 429 or gateway block after its ten-request threshold |
| Multi-step chain | Identity, enumeration, foreign-ID read and delete | Each step visible; fallback seed ID is explicitly labeled when enumeration is blocked |
| Legitimate owner access after repair | Bob requests object 2 | 200 from a repaired, unisolated API |

An API that was already isolated responds 423. Reset the selected fixture if you want to observe first detection again. A successful `/me` response is not a breach; the attacker UI does not label every 200 as exploitation. The attacker sends a descriptive User-Agent, but the gateway detects the behavior, not the label. User-Agent attribution can be spoofed and is not proof of origin.

The integration suite includes a direct internal-fixture deletion and recovery test to prove that the synthetic records can actually be deleted and restored. The external attacker cannot bypass the gateway's owner check to force a successful destructive breach during protected operation.

For a manual Windows PowerShell request after repair:

```powershell
$TOKEN_ALICE = 'lab-alice-synthetic'
$TOKEN_BOB = 'lab-bob-synthetic'
curl.exe -i -H "Authorization: Bearer $TOKEN_ALICE" "http://127.0.0.1:8000/api/orders/objects/1"
curl.exe -i -H "Authorization: Bearer $TOKEN_BOB" "http://127.0.0.1:8000/api/orders/objects/1"
```

The first request should return 200 and the second should be blocked. Reproduction commands in the report use `curl`; use `curl.exe` on Windows if your shell maps `curl` to another command. The placeholder variables deliberately remain distinct for Alice and Bob while actual tokens are redacted.

## Continuous scanning

Choose a scope in **Automation**, enable continuous scanning, set the interval and save. The first scan starts on the next scheduler tick. Only one scan runs at a time. A pending schedule does not start a second concurrent scan. Scan state, settings and the last-run timestamp persist; an interrupted scan is marked interrupted after a restart rather than falsely completed.

Scan progress and requests update while the form remains editable. Cancellation takes effect between requests, after at most the current timeout. The default budget of 600 supports the full 24-family seeded scan; the hard ceiling is 1,000.

## Optional actual LLM planner

Install and run Ollama with a local model of your choice. Set the exact model name already installed:

```powershell
$env:OLLAMA_MODEL = 'your-installed-model-name'
python run.py
```

Then click **Generate test plan** in the dashboard. The result explicitly says whether a model responded. Select **Prioritize the generated test plan** when scanning to apply valid suggested candidates first. The local adapter uses Ollama's JSON output mode. A failed or malformed model response produces a visible fallback, not fabricated AI output.

This optional mode currently targets Ollama on the same host in the Python launcher. The Compose deployment does not provision a model container or configure access to a host Ollama service. Deterministic scanning, NLP planning, containment and repair work without any LLM.

## Automated tests and CI

```sh
python -m unittest discover -s tests -v
python demo_ci.py
```

The suite exercises actual HTTP services using temporary databases and free ports, plus isolated unit tests for parsing, budgets, redaction and model output validation. Three consecutive vulnerable scans and a zero-finding repaired scan are required. It also verifies unknown target rejection, session/Origin/Host checks, missing baselines, response limits, cancelled scans, authority denial, failed-release isolation, deletion recovery and all 24 APIs within budget.

`demo_ci.py` starts another isolated lab, verifies that `ci_gate.py` returns 1 for the vulnerable fixture, repairs it, and verifies an exit code of 0. Two evidence files are written to `reports/`. In a deployment pipeline, run the gate on an authorized staging adapter before deploying; this delivered gate supports the registered sandbox only.

## Troubleshooting

| Symptom | Action |
|---|---|
| `python` is not recognized | Install Python 3.10+ or try the Windows `py` launcher |
| A service fails at startup | Check whether ports 8000, 8001 or 8002 are already occupied; stop the older demo first |
| Reload the dashboard to establish a session | Reload after a controller restart; the local session deliberately changes |
| API returns 423 | It is isolated. Repair it with authority, or run Verify & release after a verified fix |
| API stays isolated after a repair | Read the repair error; check backend health and run Verify only. Failed verification never releases traffic |
| The scan reports partial | Read the budget, timeout or baseline error; a partial scan does not mean clean |
| Bob's request gets 429 | Wait at least a second after a burst before testing legitimate access |
| Imported endpoints are inventory-only | They do not match the registered sandbox adapter; import `samples/openapi.json` for executable examples |
| YAML import fails | Try JSON or install the optional PyYAML requirement. Anchors, tags and remote references are intentionally rejected |
| LLM says unavailable | Check that Ollama is running locally and `OLLAMA_MODEL` matches an installed model; core scanning is unaffected |
| Repeated attack produces no new incident | A short deduplication window suppresses repeated incidents; the request is still blocked and logged |
| Existing findings remain after a rescan | Findings are historical evidence records. Repaired records are marked resolved; the new scan's count is separate |

## Export and offline presentation

Use **Export report** for JSON, or **Automation → Download HTML** for a standalone offline report. Both include redacted evidence, incident timelines, repairs and audit entries. Screenshots and a narrated backup video can be recorded with the user's preferred recording software; no backup video is included. The generated `reports/vulnerable.json` and `reports/repaired.json` provide a repeatable offline evidence pair.
