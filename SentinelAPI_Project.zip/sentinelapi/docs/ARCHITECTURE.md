# Architecture and trust boundaries

The three services are independently runnable. The default launcher uses only the Python standard library so the core product works offline without dependency installation. The browser interfaces are plain HTML, CSS and JavaScript; storage is SQLite.

```mermaid
flowchart LR
    A[Attacker app 8002] -->|Bounded real HTTP| G[Gateway and dashboard 8000]
    U[Operator browser] -->|Local session| G
    G --> P{API isolated?}
    P -->|Yes| B[Block request]
    P -->|No| D[Identity and owner checks]
    D -->|Allowed| S[Private synthetic backend 8001]
    S --> F[Response field and ownership filter]
    F -->|Allowed| R[Client response]
    D -->|Threat| I[Persist incident and isolate]
    F -->|Exposure| I
    I --> Q{Explicit repair authority?}
    Q -->|No| B
    Q -->|Yes and autonomous| H[Approved repair adapter]
    H --> V[Regression verification]
    V -->|Pass| O[Reopen API]
    V -->|Fail| B
    G --> SC[Bounded scanner]
    SC -->|Internal transport key| S
```

## Components and authority

The controller owns policy and evidence. The attacker has no controller database connection, repair endpoint access, or internal transport credential. It is an ordinary HTTP client using public synthetic user identities. It can select API IDs and a registered scenario, but cannot supply arbitrary URLs, scripts or payloads.

The backend is intentionally vulnerable in its application authorization layer. A separate internal transport key keeps these vulnerabilities inside the laboratory. Every backend application route requires that transport key, even in vulnerable mode. In Docker, the backend also has no host-published port, and the attacker is absent from its internal network.

Loopback-only host bindings are the default for the local launcher and published Docker ports. Host validation and Origin validation protect the local UI against ordinary rebinding/cross-origin requests. Control requests additionally require an in-memory session value returned to the same-origin dashboard. This is a single-user local operator boundary, not enterprise login or multi-tenant RBAC.

API repair is denied by default. Per-API locks serialize authority updates, gateway decisions and patch transactions. An unauthorized repair request results in containment only. Releasing an isolated API requires a successful regression check. A failed repair stays isolated.

## Evidence contract

A finding contains its ID, API ID, class, severity, confidence, method, endpoint, explanation, timestamp, exact field paths, redacted baseline and probe, reproducible requests, remediation and resolution status. A response status of 200 alone is never sufficient to confirm cross-user access: the probe must return the baseline's stable object ID and Alice ownership marker to Bob.

Sensitive values are redacted before persistence, rendering or export. Evidence keeps field paths and synthetic owner/resource IDs for comparison. Tokens exist only as intentionally public synthetic fixtures and transient request headers; real credential onboarding is not implemented. The optional model receives sanitized descriptions and registered paths, not response data or request headers.

An incident separately records detection time, source, request details, authority at detection, isolation, repair changes, verification and final outcome. Gateway incidents describe **prevented attempts**, not successful breaches. Direct scanner findings prove underlying flaws before repair. The test suite separately demonstrates actual deletion of a disposable backend record and restoration from the seed.

## Scan execution

The OpenAPI adapter accepts 3.x or Swagger 2.0 documents. It inventories supported operation metadata, descriptions, security requirements and identifier locations. It ignores all server/host declarations for network execution. Path and query identifier candidates must match the fixed registered sandbox adapter; unknown routes remain inventory-only. Local references can be stored but are not generally dereferenced into new candidates.

Core scans execute GET requests only, serially, with a caller-visible budget of up to 1,000 requests, four-second default timeout, one-MiB response limit and redirect refusal. No environment proxy is used. Cancellation takes effect before the next request. Three consecutive transport errors stop the run. Missing owner baselines produce partial results, not a misleading clean result.

The default full scan covers 48 path/query candidates across 24 API families. The eight-request rate probe is a bounded observation: an absence of 429 is not enough to prove that no longer-window limiter exists. The approved repair's known limiter is also checked during verification.

## Autonomous repair

The repair adapter activates real authorization, authentication, response filtering and rate-control code already present in the backend. It also restores the API's deterministic synthetic records. The action is recorded with before/after state and revision numbers. It is not an LLM-generated patch or a production code deployment.

Verification checks an owner's successful read, rejection of cross-user and anonymous access, absent forbidden fields, and the expected rate-limiting response. A rollback restores the initial vulnerable fixture while preserving gateway isolation. Reset is an explicit operator action to start another sandbox demo.

## Planner and bounded agent

The deterministic planner recognizes ownership language in descriptions and proposes BOLA candidates. With `OLLAMA_MODEL` set, the optional local model can propose registered path/check pairs and explanations. Output is parsed as JSON and validated against the known candidate set and check enum. A generated plan can reorder selected candidates; it cannot add a target, invoke a method, change authority, or bypass deterministic verification.

The independent attacker chain is a finite state workflow: discover identity, enumerate resources, select a discovered foreign ID (or the documented seed canary if enumeration was blocked), attempt cross-user read, then attempt a disposable delete. It has sequential execution, a 288-request total cap, bounded rate probes, timeouts, cancellation and a visible step trace. It is intentionally not an unrestricted general-purpose pentest agent.

## Persistence and operational limits

Policies, scans, findings, incidents and repairs are stored in SQLite with WAL for the controller. Recent live telemetry retains 5,000 events. Findings and incident objects are retained until the local database is replaced; the UI fetches bounded recent windows. The backend uses its own database. Attacker job history is memory-only and limited to 30 runs.

Historical finding totals represent observations at scan time, including subsequently repaired issues. Repeated scans create separate evidence records. The dependency view uses real synthetic response references; transitive traversal stops at isolated nodes. A graph path is potential exposure, not proof of exploitability.

## Scope and limitations

- This is a complete **sandbox hackathon implementation**, not a general production API-security product. The 24 families intentionally share a six-operation fixture pattern.
- It supports sandbox path/query ID testing with the two seeded identities. Arbitrary API adapters, body-ID requests, OAuth, complex roles, generic business workflows, third-party repair integrations and external traffic capture are not implemented.
- Live observation covers this gateway only. Traffic that bypasses it cannot be stopped by the gateway. The private Docker backend and separate internal transport key make that boundary concrete in the demo.
- No security system can honestly promise detection of every unknown attack. The controls here address the seeded owner/auth/field/rate policies and fail closed for isolation and failed repairs.
- Automatic repair uses pre-approved controls and synthetic seed restoration; it cannot infer and safely rewrite arbitrary business logic or restore unknown production data.
- Local UI sessions assume one trusted operator on a loopback machine. Public exposure requires real authentication, authorization, TLS, secure secret management, network policy and operational hardening.
- Request caps bound individual runs, not an enterprise workload. Large deployment scalability, distributed rate limiting, persistent job queues, multi-worker coordination and high availability are outside this implementation.
- Basic YAML is built in. Complex YAML can require optional PyYAML; anchors/tags and external references are still rejected.
- The optional local LLM path is implemented and contract-tested with fixtures; no actual model was installed for end-to-end model validation.
- Docker definitions are supplied, but Docker was unavailable for execution in this environment.
