# Validation record

Validated on 24 September 2026 using Python 3.10 on Windows.

## Executed checks

- `python -m unittest discover -s tests -v`: **34 tests passed**. The final full run completed in 23.390 seconds.
- A subsequent reproduction-placeholder redaction correction was verified by rerunning the redaction and report-export integration tests: **2 passed**.
- `python demo_ci.py`: **passed**. The vulnerable Orders scan returned exit code 1 with six confirmed High findings. The repaired scan returned exit code 0 with zero findings. These are saved in `reports/vulnerable.json` and `reports/repaired.json`.
- JavaScript syntax validation: both dashboard and attacker scripts passed.
- Three-process local startup: health checks passed for controller, sandbox and attacker.
- Browser checks: defense overview, inventory, repair selection, scan start, evidence details, incident outcomes, attacker selection and a two-API deletion attempt. The attack run completed with two requests and two blocks.
- Scope demonstration: Orders had repair authority and became secure and unisolated. Profiles lacked authority, remained vulnerable internally, and stayed isolated at the gateway.
- Evidence inspection: baseline/probe bodies retained ownership markers, sensitive values were redacted, and verified results showed 200 for owner access, 403 for cross-user access, 401 for anonymous access and zero remaining findings.

## Test coverage

The suite covers all-API scanning within budget, deterministic positive/negative detection, repeated scans, missing-baseline partial results, budgets, timeout/error stop, cancellation guard, nested field redaction, scope rejection, external-reference refusal, redirect refusal, response size limits, YAML/Swagger input, optional model output validation and fallback, session/Origin/Host controls, selected repair authority, failed-repair isolation, rollback, synthetic deletion recovery, query-ID scans, continuous scope, independent attacker HTTP requests, and rate control after repair.

## Unverified environments

Docker and an actual Ollama model were not installed on this machine. Docker configuration is included but container execution is unverified. The optional model adapter was tested with controlled responses, invalid output and an unavailable provider, rather than a live model. The GitHub Actions workflow is included but has not been run on GitHub. Public production deployment, independent security assessment, load testing and formal accessibility certification are outside this verification.

The source archive excludes live databases, generated internal secrets, caches and process logs. Extracting it starts a fresh sandbox with repair authority denied for every API.
